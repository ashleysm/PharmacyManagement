package com.cognizant.pharmacymanagement.MedicineSupply;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicineSupplyApplicationTests {

	@Test
	void contextLoads() {
	}

}
